# Decentralized Star Notary Service - Starter Code


## ERC-721 Token Name : "Star Token"
## ERC-721 Token Symbol : "STT" 
## “Token Address” on the rinkeby Network : 0xacf4467d628d0bc0c267fca043f6d6b78a95a514
